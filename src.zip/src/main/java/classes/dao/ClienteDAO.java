package classes.dao;

public class ClienteDAO {

	public ClienteDAO() {}

}
